<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$dbname = "brecho";

// Criar conexão
$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
